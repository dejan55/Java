//cd C:\Users\Home\hades\Java\coursera
//javac-algs4 PercolationStats.java
//java-algs4 PercolationStats


import java.util.Scanner;
public class PercolationStats {
   private Percolation per[];
   private int t,open,n;
   private double[] x;
   private double sum;
   public PercolationStats(int N, int T) {   // perform T independent computational experiments on an N-by-N grid
		sum=0; t=T; n=N;
		x=new double[T];
		per=new Percolation[T];
		for(int i=0;i<T;i++){
		per[i]=new Percolation(N);
		open=0;
			while(!(per[i].percolates())){
			int r1=StdRandom.uniform(1,N+1);
			int r2=StdRandom.uniform(1,N+1);
			if(!per[i].isOpen(r1,r2)){
				per[i].open(r1,r2);
				open++; }
			}
		x[i]=(double)open/(n*n);
		sum+=x[i];
		}
	}
   public double mean() {   	                // sample mean of percolation threshold
		return sum/t;
	}
   public double stddev()  {
	double sum1=0;
	for(int i=0;i<t;i++)
		sum1+=(x[i]-mean())*(x[i]-mean());
	return Math.sqrt((double)sum1/(t-1));
	}
   public double confidenceLo()  {           // returns lower bound of the 95% confidence interval
	return mean()-(1.96*stddev()/Math.sqrt(t));
	}
   public double confidenceHi()   {
	return mean()+(1.96*stddev()/Math.sqrt(t));
	}										// returns upper bound of the 95% confidence interval
   public static void main(String[] args){
	Scanner in=new Scanner(System.in);
	System.out.println("Vnesi N i T");
	int n=in.nextInt();
	int t=in.nextInt();
	PercolationStats ps=new PercolationStats(n,t);
	System.out.println("mean\t= "+ps.mean());
	System.out.println("stddev\t= " +ps.stddev());
	System.out.println("95% confidence interval = "+ ps.confidenceLo() +", "+ ps.confidenceHi());
   }
}